--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE formacionac_db;
--
-- Name: formacionac_db; Type: DATABASE; Schema: -; Owner: alumno
--

CREATE DATABASE formacionac_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE formacionac_db OWNER TO alumno;

\connect formacionac_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: professors; Type: TABLE; Schema: public; Owner: alumno
--

CREATE TABLE public.professors (
    professor_id integer NOT NULL,
    user_id integer,
    department character varying(100)
);


ALTER TABLE public.professors OWNER TO alumno;

--
-- Name: professors_professor_id_seq; Type: SEQUENCE; Schema: public; Owner: alumno
--

CREATE SEQUENCE public.professors_professor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.professors_professor_id_seq OWNER TO alumno;

--
-- Name: professors_professor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alumno
--

ALTER SEQUENCE public.professors_professor_id_seq OWNED BY public.professors.professor_id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: alumno
--

CREATE TABLE public.students (
    student_id integer NOT NULL,
    user_id integer,
    major character varying(100)
);


ALTER TABLE public.students OWNER TO alumno;

--
-- Name: students_student_id_seq; Type: SEQUENCE; Schema: public; Owner: alumno
--

CREATE SEQUENCE public.students_student_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_student_id_seq OWNER TO alumno;

--
-- Name: students_student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alumno
--

ALTER SEQUENCE public.students_student_id_seq OWNED BY public.students.student_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: alumno
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(100),
    lastname character varying(100),
    user_type character varying(50),
    dni integer,
    email character varying(100),
    phone_number character varying(15),
    date_of_birth date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_user_type_check CHECK (((user_type)::text = ANY ((ARRAY['profesor'::character varying, 'estudiante'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO alumno;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: alumno
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO alumno;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alumno
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: professors professor_id; Type: DEFAULT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.professors ALTER COLUMN professor_id SET DEFAULT nextval('public.professors_professor_id_seq'::regclass);


--
-- Name: students student_id; Type: DEFAULT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.students ALTER COLUMN student_id SET DEFAULT nextval('public.students_student_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: professors; Type: TABLE DATA; Schema: public; Owner: alumno
--

COPY public.professors (professor_id, user_id, department) FROM stdin;
\.
COPY public.professors (professor_id, user_id, department) FROM '$$PATH$$/3373.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: alumno
--

COPY public.students (student_id, user_id, major) FROM stdin;
\.
COPY public.students (student_id, user_id, major) FROM '$$PATH$$/3375.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: alumno
--

COPY public.users (id, name, lastname, user_type, dni, email, phone_number, date_of_birth, created_at) FROM stdin;
\.
COPY public.users (id, name, lastname, user_type, dni, email, phone_number, date_of_birth, created_at) FROM '$$PATH$$/3371.dat';

--
-- Name: professors_professor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alumno
--

SELECT pg_catalog.setval('public.professors_professor_id_seq', 2, true);


--
-- Name: students_student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alumno
--

SELECT pg_catalog.setval('public.students_student_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alumno
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: professors professors_pkey; Type: CONSTRAINT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.professors
    ADD CONSTRAINT professors_pkey PRIMARY KEY (professor_id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (student_id);


--
-- Name: users users_dni_key; Type: CONSTRAINT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_dni_key UNIQUE (dni);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_professor_user_id; Type: INDEX; Schema: public; Owner: alumno
--

CREATE INDEX idx_professor_user_id ON public.professors USING btree (user_id);


--
-- Name: idx_student_user_id; Type: INDEX; Schema: public; Owner: alumno
--

CREATE INDEX idx_student_user_id ON public.students USING btree (user_id);


--
-- Name: professors professors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.professors
    ADD CONSTRAINT professors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: students students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alumno
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

